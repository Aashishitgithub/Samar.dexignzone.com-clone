package com.server.utils.types;

public class OpenAIImageResultData {
  private String url;

  public String getUrl() {
    return this.url;
  }
}

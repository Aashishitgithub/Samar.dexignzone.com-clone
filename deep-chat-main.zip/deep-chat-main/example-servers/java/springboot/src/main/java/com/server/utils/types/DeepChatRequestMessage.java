package com.server.utils.types;

public class DeepChatRequestMessage {
  private String role;
  private String text;

  public String getRole() {
    return this.role;
  }

  public String getText() {
    return this.text;
  }
}

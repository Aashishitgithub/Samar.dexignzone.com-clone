export interface PermittedErrorMessage {
  permittedErrorMessage: string;
}

export type FILE_TYPES = 'images' | 'gifs' | 'audio' | 'mixedFiles';

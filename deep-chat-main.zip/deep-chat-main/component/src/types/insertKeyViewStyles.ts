export interface InsertKeyViewStyles {
  displayCautionText?: boolean;
}
